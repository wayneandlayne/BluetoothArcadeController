This kicad file archive was generated on 2011-08-30.
For more details, please visit http://www.wayneandlayne.com/projects/bluetooth-arcade-controller/
